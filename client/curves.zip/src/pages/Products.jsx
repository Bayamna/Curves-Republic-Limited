import React from 'react'

const Products = () => {
  return (
    <div className='mt-[10rem] flex flex-col min-h-screen p-10'>
    <div className='flex-grow'>
      <h1 className='text-lightBrown font-bold text-4xl text-center'>Under construction!!!</h1>
    </div>
    </div>
  )
}

export default Products
